<?php

namespace Plugin\DataRecharge\app\Http\Controllers;

use App\Http\Controllers\PluginController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Payments\EPay;

class DataRechargeController extends PluginController
{
    public function recharge(Request $request)
    {
        $this->setPluginCode('data_recharge');
        $amount = $request->input('amount');
        $token = $request->bearerToken();

        if (!$token) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $hashedToken = hash('sha256', $token);

        $personalAccessToken = DB::table('personal_access_tokens')
            ->where('token', $hashedToken)
            ->first();

        if (!$personalAccessToken || now()->gt($personalAccessToken->expires_at)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $user = User::find($personalAccessToken->tokenable_id);

        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        $pricePerGb = (float) $this->getConfig('price_per_gb', 1);
        $minRechargeAmount = (float) $this->getConfig('min_recharge_amount', 1);

        $totalPrice = $pricePerGb * $amount;

        if ($totalPrice < $minRechargeAmount) {
            return response()->json(['error' => 'Amount is less than the minimum recharge amount'], 400);
        }

        $orderId = uniqid();

        cache(['recharge_user_' . $orderId => $user->id], now()->addMinutes(5));

        $payment = new EPay([
            'epay_pid' => env('EPAY_PID'),
            'epay_key' => env('EPAY_KEY'),
            'epay_url' => env('EPAY_URL'),
        ]);

        $params = [
            'pid' => env('EPAY_PID'),
            'type' => 'alipay',
            'out_trade_no' => $orderId,
            'notify_url' => url('/api/datarecharge/notify'),
            'return_url' => url('/'),
            'name' => 'Data Recharge',
            'money' => $totalPrice,
            'sitename' => 'Xboard',
        ];

        $paymentUrl = $payment->pay($params);

        return response()->json(['payment_url' => $paymentUrl]);
    }

    public function notify(Request $request)
    {
        $this->setPluginCode('data_recharge');
        $params = $request->all();

        $payment = new EPay([
            'epay_pid' => env('EPAY_PID'),
            'epay_key' => env('EPAY_KEY'),
            'epay_url' => env('EPAY_URL'),
        ]);

        if (!$payment->verify($params)) {
            return response('fail');
        }

        if ($params['trade_status'] === 'TRADE_SUCCESS') {
            $orderId = $params['out_trade_no'];
            $amount = (float) $params['money'];
            $userId = cache('recharge_user_' . $orderId);

            if (!$userId) {
                return response('fail');
            }

            $user = User::find($userId);

            if (!$user) {
                return response('fail');
            }

            $pricePerGb = (float) $this->getConfig('price_per_gb', 1);
            $data = ($amount / $pricePerGb) * 1024 * 1024 * 1024;
            $user->transfer_enable += $data;
            $user->save();

            cache()->forget('recharge_user_' . $orderId);
        }

        return response('success');
    }
}
