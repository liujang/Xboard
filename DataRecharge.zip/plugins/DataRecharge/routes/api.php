<?php

use Illuminate\Support\Facades\Route;
use Plugin\DataRecharge\app\Http\Controllers\DataRechargeController;

Route::post('/api/datarecharge/recharge', [DataRechargeController::class, 'recharge']);
Route::post('/api/datarecharge/notify', [DataRechargeController::class, 'notify']);
