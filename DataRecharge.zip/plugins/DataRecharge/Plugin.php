<?php

namespace Plugin\DataRecharge;

use App\Services\Plugin\AbstractPlugin;

class Plugin extends AbstractPlugin
{
    public function boot(): void
    {
        $this->loadRoutes(__DIR__ . '/routes');
    }
}
